These results generated with revision 61 from 

https://software.sandia.gov/svn/public/DPG

and a prerelease version of Trilinos 10.7.

(Ran the convergenceStudyScript in the SummerProceedings2011 directory to produce them.)